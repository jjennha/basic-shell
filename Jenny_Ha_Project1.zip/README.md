# basic-shell

(1) Run "make all" to build
(2) Run "./myshell" to build
